#!/bin/bash

# === CONFIG ===
PROJECT_DIR="/home/user/app_eventmanagement"
DEPLOY_DIR="/home/user/public_html/app"  # Change this to your subdomain's document root
LOG_FILE="$PROJECT_DIR/deploy.log"

# === START LOGGING ===
echo "=== Deploy Started: $(date) ===" >> "$LOG_FILE"

# Go to project directory
cd "$PROJECT_DIR" || exit

# Pull latest changes
echo "Pulling latest changes..." | tee -a "$LOG_FILE"
git pull origin main >> "$LOG_FILE" 2>&1

# Install dependencies
echo "Installing dependencies..." | tee -a "$LOG_FILE"
npm install >> "$LOG_FILE" 2>&1

# Build project
echo "Building project..." | tee -a "$LOG_FILE"
npm run build >> "$LOG_FILE" 2>&1

# Clean old deployment (optional)
echo "Cleaning old files in $DEPLOY_DIR..." | tee -a "$LOG_FILE"
rm -rf "$DEPLOY_DIR"/*

# Copy new build to subdomain root
echo "Deploying new build to $DEPLOY_DIR..." | tee -a "$LOG_FILE"
cp -r "$PROJECT_DIR/dist/"* "$DEPLOY_DIR"/ >> "$LOG_FILE" 2>&1

# Add .htaccess
cat <<EOL > "$DEPLOY_DIR/.htaccess"
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
EOL

echo ".htaccess file added." | tee -a "$LOG_FILE"

echo "✅ Deploy complete at $(date)" | tee -a "$LOG_FILE"
echo "===============================" >> "$LOG_FILE"
